# T81 - Applications of Deep Learning Kaggle

**Group**: DCDS Nerds

**Members:** Tom Earnest (me), Robert Jirsarie

**Group Ratings**:

Me: 5/5

Robert: 5/5

## Brief note

This zip contains the code implemented by Tom for the Kaggle competition.  The final score submitted to Kaggle (Mean_Tom_Rob.csv) is an even average of predictions from this model and one implemented by Robert.

